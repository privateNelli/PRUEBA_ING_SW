from django.urls import path,include
from . import views
from django.contrib import admin 

urlpatterns = [
    
    path("home/",views.home, name="home" ),
    path("moca/", views.moca, name="moca" ),
    path("login/", views.login, name="login"),
    path("beneficio/", views.beneficio, name="beneficio"),
    path("expreso/", views.expreso, name="expreso"),
    path("capuchino/", views.capuchino, name="capuchino"),
    path("carrito/", views.carrito, name="carrito"),
    path('eliminar-producto/<int:producto_id>/', views.eliminar_producto_carrito, name='eliminar_producto'),
    path("productos/",views.productos, name="productos"),
    path('agregar-producto/', views.agregar_producto, name='agregar_producto'),
]
    
    
    
