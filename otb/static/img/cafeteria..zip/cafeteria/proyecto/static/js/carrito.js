// Función para obtener los productos del carrito desde localStorage
function getProductosEnCarrito() {
    return JSON.parse(localStorage.getItem('productosEnCarrito')) || [];
}

// Función para guardar los productos del carrito en localStorage
function guardarProductosEnCarrito(productos) {
    localStorage.setItem('productosEnCarrito', JSON.stringify(productos));
}

// Función para actualizar la interfaz del carrito
function actualizarCarrito() {
    const carritoItems = document.querySelector('.cart-items');
    const productosEnCarrito = getProductosEnCarrito();

    carritoItems.innerHTML = ''; // Limpiar la lista antes de actualizar

    if (productosEnCarrito.length > 0) {
        productosEnCarrito.forEach(item => {
            const listItem = document.createElement('li');
            listItem.classList.add('cart-item');
            listItem.innerHTML = `
                <div class="item-details">
                    <img src="{% static 'img/producto-placeholder.jpg' %}" alt="Producto">
                    <div>
                        <h3>${item.nombre}</h3>
                        <p>Precio: $${item.precio}</p>
                        <button class="remove-from-cart" data-product-id="${item.id}">Eliminar</button>
                    </div>
                </div>
            `;
            carritoItems.appendChild(listItem);
        });
    } else {
        carritoItems.innerHTML = '<p>No hay productos en el carrito.</p>';
    }
}

// Función para eliminar un producto del carrito
function eliminarDelCarrito(productId) {
    let productosEnCarrito = getProductosEnCarrito();
    productosEnCarrito = productosEnCarrito.filter(item => item.id !== productId);
    guardarProductosEnCarrito(productosEnCarrito);
    actualizarCarrito();
}

// Manejar eventos después de que se cargue el DOM
document.addEventListener('DOMContentLoaded', function() {
    actualizarCarrito();

    // Escuchar clics en botones "Eliminar" dentro del carrito
    const cartItems = document.querySelector('.cart-items');
    cartItems.addEventListener('click', function(event) {
        if (event.target.classList.contains('remove-from-cart')) {
            const productId = event.target.getAttribute('data-product-id');
            eliminarDelCarrito(productId);
        }
    });
});
