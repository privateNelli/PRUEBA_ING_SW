// Función para actualizar el contador del carrito en la interfaz
function actualizarContadorCarrito() {
    const contador = document.querySelector('.content-shopping-cart .number');
    if (contador) {
        contador.textContent = `(${getProductosEnCarrito()})`;
    }
}

// Función para obtener el número de productos en el carrito desde localStorage
function getProductosEnCarrito() {
    return parseInt(localStorage.getItem('numProductosEnCarrito')) || 0;
}

// Función para guardar el número de productos en el carrito en localStorage
function guardarProductosEnCarrito(cantidad) {
    localStorage.setItem('numProductosEnCarrito', cantidad);
}

document.addEventListener('DOMContentLoaded', function() {
    // Actualizar el contador al cargar la página
    actualizarContadorCarrito();

    // Escuchar el evento de clic en el botón "Agregar al carrito"
    const botonAgregar = document.querySelector('.add-to-cart');
    if (botonAgregar) {
        botonAgregar.addEventListener('click', function() {
            let cantidadActual = getProductosEnCarrito();
            cantidadActual++;
            guardarProductosEnCarrito(cantidadActual);
            actualizarContadorCarrito();
        });
    }
});
