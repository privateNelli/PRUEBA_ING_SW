from django.shortcuts import render, redirect
from django.http import HttpResponse
from .models import Producto
from django.shortcuts import get_object_or_404, redirect
from django.views.decorators.http import require_POST
from django.contrib.auth import login, authenticate, logout
from django.contrib.auth.forms import AuthenticationForm
from .forms import UserRegisterForm
from django.contrib import messages

# Create your views here.

def home(request):
    context={

    }
    return render(request,"proyecto/index.html",context) 

def moca(request):
    context={

    }
    return render(request,"proyecto/moca.html",context)

def login(request):
    context={

    }
    return render(request,"proyecto/login.html",context)

def beneficio(request):
    context={

    }
    return render(request,"proyecto/beneficio.html",context)

def expreso(request):
    context={

    }
    return render(request,"proyecto/expreso.html",context)

def capuchino(request):
    context={

    }
    return render(request,"proyecto/capuchino.html",context)

def carrito(request):
    # Código para manejar el carrito de compras
    productos_carrito = Producto.objects.all()  # Ejemplo de consulta de productos
    context = {
        'productos_carrito': productos_carrito
    }
    return render(request, 'proyecto/carrito.html', context)



def carrito(request):
    # Simulación de productos en el carrito (puedes adaptar esta lógica según tu aplicación)
    productos_carrito = [
        {'nombre': 'Café Moca Helado', 'precio': 6.20, 'cantidad': 2},
        {'nombre': 'Café Irish', 'precio': 4.60, 'cantidad': 1},
        {'nombre': 'Café Inglés', 'precio': 5.70, 'cantidad': 3},
    ]

    context = {
        'productos_carrito': productos_carrito
    }
    
    return render(request, 'proyecto/carrito.html', context)

def carrito_de_compras(request):
    productos_carrito = Producto.objects.all()  # Obtener todos los productos, ajusta esto según tu lógica de negocio
    context = {
        'productos_carrito': productos_carrito
    }
    return render(request, 'proyecto/carrito.html', context)



@require_POST
def eliminar_producto_carrito(request, producto_id):
    producto = get_object_or_404(Producto, id=producto_id)
    # Aquí puedes agregar lógica para eliminar el producto del carrito
    # Por ejemplo, si tienes un carrito asociado al usuario, podrías hacer algo como:
    # request.user.carrito.remove(producto)
    # o marcar el producto como no incluido en el carrito
    return redirect('carrito')

def vista_carrito(request):
    productos_carrito = Producto.objects.all()  # Ejemplo básico, ajusta según tu lógica de negocio
    return render(request, 'tu_app/tu_template.html', {'productos_carrito': productos_carrito})

def productos(request):
    productos = Producto.objects.all()
    return render(request, 'proyecto/productos.html', {'productos': productos})

def agregar_producto(request):
    if request.method == "POST":
        # Lógica para agregar un nuevo producto
        nombre = request.POST.get('nombre')
        precio = request.POST.get('precio')
        # Crea un nuevo producto (esto es solo un ejemplo, ajusta según tu modelo)
        Producto.objects.create(nombre=nombre, precio=precio)
        return redirect('lista_productos')  # Ajusta según tu vista de lista de productos
    return render(request, 'proyecto/agregar_producto.html')

